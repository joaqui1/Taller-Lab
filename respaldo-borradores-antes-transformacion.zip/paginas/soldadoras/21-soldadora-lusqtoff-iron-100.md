---
title: "Lusqtoff Iron 100: ficha del kit con máscara y escuadras"
h1: "Soldadora Lusqtoff Iron 100: qué incluye y para quién sirve"
url: "/soldadoras/lusqtoff-iron-100/"
description: "Revisamos el kit MEGAIRON100-8 de Lusqtoff: corriente, ciclo de trabajo, electrodos admitidos, máscara ST-1X y dos escuadras magnéticas."
author: "Taller Lab"
category: "Soldadoras y Soldadura"
keywords: ["soldadora lusqtoff iron 100", "iron 100 lusqtoff", "lusqtoff iron 100", "megairon100-8"]
---

# Soldadora Lusqtoff Iron 100: qué incluye y para quién sirve

La Lüsqtoff Iron 100 conviene solo si su corriente y ciclo de trabajo alcanzan para tus electrodos y espesor. Confirmá el código, alimentación y accesorios del kit antes de comprar.

## Datos que importan al comprar

| Característica | MEGAIRON100-8 según Lusqtoff | Qué significa |
| :--- | :--- | :--- |
| Alimentación | 220 V, 50 Hz | Revisá que la publicación y la placa correspondan a esta versión. |
| Rango de soldadura | 20 a 105 A | La corriente ajustada depende del electrodo y del material. |
| Ciclo de trabajo | 105 A al 30 %; 74 A al 60 %; 57 A al 100 % | A la corriente máxima necesita pausas para enfriar. |
| Tensión en vacío | 66 V | Dato útil al comparar facilidad de encendido, sin prometer el mismo resultado con todo electrodo. |
| Electrodos indicados | 1,6 a 2,5 mm | No la elijas suponiendo uso continuo con varillas de 3,25 mm. |

Los porcentajes de ciclo provienen del [manual del fabricante](https://www.lusqtoff.com.ar/2023/uploads/Productos/NUEVOS/SOLDADORAS_INVERTER/MEGAIRON100-8/manual%20MEGAIRON100-8_compressed%20%281%29.pdf). Expresan tiempo de arco dentro de un período de diez minutos bajo las condiciones de ensayo. En un trabajo con muchos puntos cortos habrá pausas naturales, pero eso no convierte a la máquina en un equipo de producción continua a 105 A.

## Qué trae el kit y qué comprobar

La presentación oficial incluye **máscara ST-1X** y **dos escuadras LQE-6001**. El manual describe para la máscara dos sensores, área de visión de 92 × 42 mm y rango de sombra DIN 9–13; para las escuadras, ángulos de 45°, 90° y 135°. Antes de pagar, compará la lista de accesorios de la publicación concreta con las fotos y el código de la caja. Un vendedor puede ofrecer la misma soldadora sola o armar un combo distinto.

También verificá que estén los cables con pinza de masa y portaelectrodo, su longitud y el estado de los conectores. La máscara del kit permite comenzar, pero conviene confirmar ajuste, funcionamiento del filtro y disponibilidad de micas de repuesto. Sumá [guantes adecuados para soldar](/soldadoras/guantes/): las escuadras mantienen las piezas alineadas, pero no protegen las manos.

## Cuándo elegirla

Tiene sentido para unir o reparar piezas pequeñas con electrodos de 1,6 a 2,5 mm y sesiones intermitentes. Si tu trabajo habitual requiere cordones largos, electrodos mayores o piezas gruesas, compará corriente y ciclo de trabajo con una [inverter de 160 A](/soldadoras/soldadora-inverter-160-amp/) o una máquina superior. Si lo que querés es avanzar sobre chapa fina con alambre continuo, buscá una [MIG sin gas](/soldadoras/mig-sin-gas/): la Iron 100 es una soldadora MMA, no una MIG.

**Aviso de afiliados:** Taller Lab puede recibir una comisión por compras realizadas desde estos enlaces.

[Ver el kit MEGAIRON100-8 con máscara y escuadras en Mercado Libre](https://meli.la/1knTbU1){:target="_blank" rel="sponsored" .btn-mercado-libre}

Para seguir comparando: [guía de soldadoras Lusqtoff](/soldadoras/lusqtoff/), [Iron 250](/soldadoras/lusqtoff-iron-250/).
