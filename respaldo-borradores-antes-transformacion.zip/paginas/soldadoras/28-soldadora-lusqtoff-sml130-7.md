---
title: "Lusqtoff SML130-7: modelo, alambre y qué revisar"
h1: "Soldadora Lusqtoff SML130-7: comprobaciones de compra"
url: "/soldadoras/lusqtoff-sml130-7/"
description: "Guía para identificar la Lusqtoff SML130-7, revisar su manual, alambre y accesorios, y evitar confundirla con SML120 o SML150."
author: "Taller Lab"
category: "Soldadoras y Soldadura"
keywords: ["lusqtoff sml130 7", "soldadora lusqtoff sml 130 7", "sml130 7", "soldadora mig lusqtoff 130"]
---

# Soldadora Lusqtoff SML130-7: comprobaciones de compra

Antes de elegir una SML130-7, confirmá el código de la máquina y contrastá alimentación, procesos, corriente y ciclo de trabajo con tu tarea. Revisá por separado el contenido y la garantía del kit anunciado.

## Qué comprobar

| Dato | Por qué pedirlo |
| :--- | :--- |
| Foto de la placa | Identifica código, tensión y corriente nominal de la unidad. |
| Estado del devanador y la torcha | Son partes clave para alimentar el alambre sin atascos. |
| Diámetro de alambre y carrete | Evita comprar [alambre Flux](/soldadoras/alambre-flux/) que no encaje. |
| Puntas y boquillas | Confirma que hay consumibles disponibles localmente. |
| Manual, garantía y accesorios | Distingue máquina sola de un kit y aclara soporte posterior. |

Si el anuncio dice «MIG sin gas», verificá que el alambre propuesto sea autoprotegido y que el manual admita esa configuración. Para un comprador que recién empieza, la [guía de MIG sin gas](/soldadoras/mig-sin-gas/) explica el proceso; la [comparativa MIG Lusqtoff](/soldadoras/mig-lusqtoff/) ayuda a elegir entre modelos.

## Compra usada o de stock anterior

En una máquina usada pedí foto del frente, placa, interior del compartimiento de alambre, torcha y conectores. Una prueba de arco con el consumible adecuado vale más que una foto del display encendido. Averiguá si la torcha y el motor de arrastre tienen repuestos compatibles y si el vendedor entrega todos los elementos ofrecidos.

No atribuyas a esta SML130-7 los **120 A Flux** declarados para la SML120-8D ni el equipamiento de un combo SML150. Compará cada equipo contra su propia ficha y el trabajo que vas a hacer.

[Ver Lusqtoff SML130-7 en Mercado Libre](https://listado.mercadolibre.com.ar/soldadora-lusqtoff-sml130-7){:target="_blank" rel="sponsored" .btn-mercado-libre}

Para seguir comparando: [SML120-8D](/soldadoras/lusqtoff-sml120-8d/), [SML150-8](/soldadoras/lusqtoff-sml150-8/).
