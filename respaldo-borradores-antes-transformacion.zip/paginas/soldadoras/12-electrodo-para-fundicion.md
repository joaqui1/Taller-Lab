---
title: "Electrodo para fundición: tipos y cuál elegir"
h1: "Cómo elegir un electrodo para fundición"
url: "/soldadoras/electrodo-para-fundicion/"
description: "Guía técnica de Taller Lab sobre electrodos para soldar fundición de hierro en Argentina: Ni-CI (níquel puro), NiFe-CI (ferroníquel), técnicas en frío y marcas como Conarco y Esab."
author: "Taller Lab"
category: "Soldadoras y Soldadura"
keywords: ["electrodo para fundicion", "soldar fundicion de hierro", "electrodo niquel puro", "electrodo ferroniquel", "conarco fundicion"]
---

# Cómo elegir un electrodo para fundición

Elegí el electrodo para fundición según el tipo de pieza, tamaño de la reparación y procedimiento térmico que requiere. Confirmá clasificación y método con una fuente técnica antes de soldar una pieza crítica.

---

## Identificar el material y la reparación

Antes de encender el arco, es imperativo identificar la naturaleza de la fundición y las exigencias mecánicas de la pieza dañada:

```
[ Tipo de Fundición de Hierro ]
  ├── Fundición Gris (Hojuelas de Grafito) ──> Bloques de motor, bombas de agua, bases de máquinas
  │    └── Muy frágil, baja resistencia a tracción, absorbe vibraciones
  ├── Fundición Nodular / Dúctil (Grafito Esferoidal) ──> Brazos de suspensión, cigüeñales, válvulas
  │    └── Mayor resistencia mecánica y cierta elasticidad
  └── Fundición Maleable ──> Accesorios para cañerías roscadas, eslabones de cadena, cajas de cambios
```

### Trabajos de reparación más comunes:
1. **Fisuras por congelamiento**: Bloques de motor o tapas de cilindro rajadas por agua congelada durante heladas invernales en maquinaria agrícola o motores antiguos.
2. **Reconstrucción de orejas de fijación partidas**: Soportes de alternador, carcasas de cajas reductoras o bridas de bombas hidráulicas sometidas a sobreesfuerzo de bulones.
3. **Relleno de defectos de fundición y desgastes**: Dientes de engranajes partidos o guías de bancadas de tornos.

---

## Diferencias entre tipos de electrodos

La norma **AWS A5.15** clasifica los electrodos para hierro fundido según la composición de su alma metálica:

| Clasificación AWS | Composición del Alma | Dureza del Depósito | Maquinabilidad Posterior | Aplicación Óptima |
| :--- | :---: | :---: | :---: | :--- |
| **ENi-CI (Níquel Puro)** | ~ 95% – 99% Níquel | 130 – 170 HB | **Excelente (Fácil de limar o tornear)** | Fisuras en fundición gris delgada, tapas de motor, uniones estancas. |
| **ENiFe-CI (Ferroníquel)** | ~ 55% Níquel + 45% Hierro | 180 – 220 HB | Buena (Requiere widia o carburo) | Fundición nodular pesada, piezas de alta carga mecánica y uniones con acero. |
| **ENiCu-B (Monel / Ni-Cu)** | ~ 65% Ni + 30% Cu | 140 – 180 HB | Muy Buena | Color coincidente con la fundición; piezas ornamentales. |
| **ESt (Acero dulce para fundición)**| Alma de acero con fundente especial | > 300 HB (Zona frágil) | No maquinable | Solo relleno no estructural o pasadas intermedias de sellado. |

### ¿Cuándo elegir Níquel Puro (ENi-CI) vs. Ferroníquel (ENiFe-CI)?
* **Níquel Puro (Conarco Ch-8 / Esab Ni-CI)**: El depósito es sumamente blando y dúctil. Al enfriarse, el níquel se estira plásticamente absorbiendo las tensiones de contracción de la fundición circundante. Se trabaja a mano con lima sin esfuerzo.
* **Ferroníquel (Conarco Ch-10 / Esab NiFe-CI)**: Ofrece un coeficiente de dilatación térmica más compatible con piezas gruesas y resiste mayores esfuerzos de corte y flexión. Además, tolera mejor fundiciones con alto fósforo o contaminadas de aceite.

---

## Compatibilidad y ficha técnica

El éxito de una soldadura en fundición no reside en el equipo, sino en la **disciplina del procedimiento operativo**:

### Parámetros eléctricos recomendados:
* **Diámetro habitual**: 2,5 mm y 3,25 mm.
* **Polaridad**: Corriente continua polaridad inversa (**DCEP / portaelectrodo al $+$**) para arco suave, o **AC** con alto voltaje en vacío.
* **Amperaje bajo**: 2,5 mm opera entre **50 A y 75 A**; 3,25 mm entre **80 A y 110 A**. Se debe aplicar el mínimo amperaje que garantice estabilidad de arco para no sobrecalentar el metal base.

### Protocolo de aplicación en frío (*Cold Welding Method*):
1. **Preparación del bisel**: Amolar la rajadura en forma de U ancha (nunca en V cerrada). Taladrar agujeros de alivio de 3 a 4 mm en los dos extremos finales de la fisura para detener la propagación de la grieta.
2. **Cordones cortos**: Depositar cordones discontinuos de no más de **20 mm a 30 mm de largo**. Nunca tirar cordones continuos.
3. **Martillado inmediato (*Peening*)**: Apenas apagado el arco y mientras el cordón esté al rojo cereza, golpear de inmediato la costura con el extremo cónico de la piqueta o un punzón de punta redondeada. Este martillado deforma mecánicamente el níquel blando, contrarrestando la tensión de tracción por enfriamiento.
4. **Enfriamiento controlado**: No reiniciar otro cordón hasta que se pueda apoyar la mano desnuda sobre la pieza adyacente. Jamás enfriar con agua o aire comprimido.

> **Regla de taller**: En fundiciones viejas impregnadas de grasa o aceite de motor (como cárteres o cajas reductoras), quemá previamente la zona del bisel con soplete a 200 °C - 300 °C hasta que deje de salir humo azulado de aceite quemado; de lo contrario, el aceite ebullirá dentro del arco formando una masa esponjosa de poros.

---

## Opciones de compra

Los electrodos de fundición son consumibles de alto valor debido a la cotización internacional del níquel puro:
1. **Conarco Ch-8 (Níquel) y Ch-10 (Ferroníquel)**: Las referencias nacionales estándar de mayor confiabilidad metalúrgica en talleres argentinos.
2. **Böhler Fox Níquel / Esab OK 92.18**: Opciones de máxima pureza para rectificadores de motores y tornerías de precisión.
3. **Fraccionamiento por unidad**: En ferreterías industriales y Mercado Libre es común adquirirlos sueltos por unidad (1, 5 o 10 varillas) o en paquetes sellados de 1 kg, evitando tener que comprar cajas completas para una reparación puntual.

[Ver electrodo para fundicion en Mercado Libre](https://listado.mercadolibre.com.ar/electrodo-fundicion){:target="_blank" rel="sponsored" .btn-mercado-libre}

Para seguir comparando: [electrodo 6013](/soldadoras/electrodo-6013/), [electrodo 7018](/soldadoras/electrodo-7018/), [guía central de soldadoras](/soldadoras/).
